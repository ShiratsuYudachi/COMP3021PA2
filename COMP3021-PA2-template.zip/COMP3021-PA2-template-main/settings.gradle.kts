rootProject.name = "COMP3021-PA2-template"

