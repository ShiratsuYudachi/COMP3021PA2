package hk.ust.comp3021;

public interface Event {
}
