package hk.ust.comp3021.constants;

public enum ActivityState {
    OPEN,
    FINISHED,
    CANCELLED,
}
