package hk.ust.comp3021.constants;

public enum ManagementActionType {
    ACTIVITY_FINISHED,
    ACTIVITY_POSTPONED,
    ACTIVITY_CANCELLED,
}
