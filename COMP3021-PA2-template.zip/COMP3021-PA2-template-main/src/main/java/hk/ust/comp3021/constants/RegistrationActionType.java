package hk.ust.comp3021.constants;

public enum RegistrationActionType {
    ENROLL,
    DROP
}
